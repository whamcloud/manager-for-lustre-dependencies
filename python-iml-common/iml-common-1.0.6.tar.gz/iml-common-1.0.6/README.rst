A Python package that contains common components for the IML project
====================================================================

Different areas of the IML project utilise common code that is shared
distributed through this package.

This packaging intends to improve code reuse and componentization
within the IML project.
