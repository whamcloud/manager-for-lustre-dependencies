# iml-common

[![Build Status](https://travis-ci.org/intel-hpdd/iml-common.svg?branch=master)](https://travis-ci.org/intel-hpdd/iml-common)

iml-common is a python library package required by the agent and manager.
