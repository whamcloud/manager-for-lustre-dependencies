.. _guide-producers:

===========
 Producers
===========

.. _producer-basics:

Basics
======


Serialization
=============

See :ref:`guide-serialization`.


Reference
=========

.. autoclass:: kombu.Producer
    :noindex:
    :members:
