# iml_sos_plugin

[![Build Status](https://travis-ci.org/intel-hpdd/iml_sos_plugin.svg?branch=master)](https://travis-ci.org/intel-hpdd/iml_sos_plugin)

A sosreport plugin for collecting IML data.
