#!/bin/bash

cfg=$1
fspath=$2
output=$3

echo $cfg > $output.1
echo $fspath > $output.2
