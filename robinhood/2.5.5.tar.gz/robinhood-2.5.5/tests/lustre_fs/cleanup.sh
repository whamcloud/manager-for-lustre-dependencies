#!/bin/sh
rm -f rh_*.log
