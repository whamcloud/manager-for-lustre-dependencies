indent -gnu -nut -i4 -npsl -di 15 -cd 50 -npcs -prs -l80 -hnl -bli0 *.[ch]
rm *~
