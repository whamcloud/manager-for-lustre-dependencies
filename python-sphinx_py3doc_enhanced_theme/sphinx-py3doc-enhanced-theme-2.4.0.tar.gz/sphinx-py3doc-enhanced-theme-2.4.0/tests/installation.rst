============
Installation
============

At the command line::

    pip install sphinx-py3doc-enhanced-theme
