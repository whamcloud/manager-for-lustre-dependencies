Welcome to Enhanced Sphinx theme (based on Python 3 docs)'s documentation!
==========================================================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   installation
   usage
   reference/index
   contributing
   authors
   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

