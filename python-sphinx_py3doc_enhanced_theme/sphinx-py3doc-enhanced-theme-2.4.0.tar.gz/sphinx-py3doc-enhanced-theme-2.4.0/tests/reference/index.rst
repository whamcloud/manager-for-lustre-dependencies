Reference
=========

.. toctree::
    :glob:

    foo*
