﻿
Authors
=======

* Ionel Cristian Mărieș - https://blog.ionelmc.ro
* Joel Frederico - https://github.com/joelfrederico
* Daniel Oaks - http://danieloaks.net/
* Matthias Geier - https://github.com/mgeier
* Marius P Isken - https://github.com/miili
