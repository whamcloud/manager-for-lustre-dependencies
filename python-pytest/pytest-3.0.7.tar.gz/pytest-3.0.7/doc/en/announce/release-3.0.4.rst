pytest-3.0.4
============

pytest 3.0.4 has just been released to PyPI.

This release fixes some regressions and bugs reported in the last version, 
being a drop-in replacement. To upgrade::

  pip install --upgrade pytest
  
The changelog is available at http://doc.pytest.org/en/latest/changelog.html.

Thanks to all who contributed to this release, among them:

* Bruno Oliveira
* Dan Wandschneider
* Florian Bruhin
* Georgy Dyuldin
* Grigorii Eremeev
* Jason R. Coombs
* Manuel Jacob
* Mathieu Clabaut
* Michael Seifert
* Nikolaus Rath
* Ronny Pfannschmidt
* Tom V

Happy testing,
The pytest Development Team
